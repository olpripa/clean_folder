# clean_folder
 Сортування файлів в папці
